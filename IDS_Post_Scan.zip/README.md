# IDS do IFE — Detecção de Port Scan com IA

Sistema de detecção de intrusão que identifica varreduras de portas contra uma
rede de entretenimento de bordo (IFE) simulada, usando **Random Forest** e
**Isolation Forest**, com painel web em tempo real.

**Topologia:** o Raspberry Pi 5 é ao mesmo tempo o ponto de acesso `IFE-Cabin`,
o alvo IFE, o sensor e o dashboard. A VM Kali se conecta nessa rede como um
"passageiro" e roda os scans.

> Laboratório fechado, com equipamento próprio. A rede `IFE-Cabin` é do seu lab.

---

## Arquivos do projeto

| Arquivo | Onde roda | Função |
|---|---|---|
| `setup_pi.sh` | Pi | Instala tudo e diagnostica a antena |
| `start_ap.sh` | Pi | Sobe/derruba a rede `IFE-Cabin` |
| `ife_services.py` | Pi | Abre as portas dos "serviços de bordo" |
| `features.py` | Pi | Extrai as features de fluxo (usado no treino e na operação) |
| `collect.py` | Pi | Captura e rotula os dados de treino |
| `train.py` | Pi ou PC | Treina os modelos |
| `dashboard.py` | Pi | Sensor em tempo real + painel web |
| `gerar_trafego_normal.sh` | **Kali** | Simula uso legítimo |
| `gerar_scans.sh` | **Kali** | Dispara a bateria de scans |

---

## Passo 1 — Instalar o sistema no Pi

Grave o **Raspberry Pi OS (64-bit)** com o Raspberry Pi Imager. A variante
**Lite** basta (o Pi roda headless). Já configure usuário, senha e SSH no
próprio Imager.

Copie a pasta do projeto para o Pi e execute:

```bash
cd ~/ids-ife
chmod +x *.sh
./setup_pi.sh
```

O script instala tudo, cria o `venv/` e, no fim, mostra as interfaces e se a
antena aceita **modo AP**. Anote o nome da interface externa (normalmente
`wlan1`; o WiFi interno costuma ser `wlan0`).

> Se aparecer `[ATENCAO] Modo AP nao encontrado`: use `wlan0` (WiFi interno)
> como AP, ou faça um primeiro teste ligando Kali e Pi por cabo.

---

## Passo 2 — Subir a rede IFE-Cabin

Edite o topo do `start_ap.sh` (interface, SSID, senha) e rode:

```bash
./start_ap.sh
./start_ap.sh status     # conferir
```

O Pi passa a ser `10.10.0.1` e entrega DHCP aos clientes.

---

## Passo 3 — Ligar os serviços do IFE

Em um terminal separado (deixe aberto durante todo o lab):

```bash
cd ~/ids-ife
python3 ife_services.py
```

---

## Passo 4 — Conectar a VM Kali

**4.1 Repassar a antena 2 para a VM (USB passthrough)**

- *VirtualBox*: com a VM desligada → **Configurações → USB** → habilite o
  controlador e adicione um filtro com o adaptador. Com a VM ligada:
  **Dispositivos → USB → [adaptador]**. (Requer o Extension Pack.)
- *VMware*: **VM → Removable Devices → [adaptador] → Connect**.

**4.2 Conectar na rede**

```bash
ip link                       # confirme que surgiu uma wlanX
nmcli device wifi rescan
nmcli device wifi connect "IFE-Cabin" password "flight1234"
ip addr                       # deve receber 10.10.0.x
ping -c 3 10.10.0.1
```

**4.3 Teste de fumaça**

```bash
nmap 10.10.0.1
```

Se as portas do `ife_services.py` aparecerem como `open`, o cenário está pronto.

---

## Passo 5 — Coletar os dados de treino

Copie os dois scripts auxiliares para o Kali (`gerar_trafego_normal.sh` e
`gerar_scans.sh`) e dê `chmod +x`.

**5.1 Classe `normal`** — no **Pi**:

```bash
cd ~/ids-ife
sudo venv/bin/python collect.py normal --iface wlan1
```

No **Kali**, em paralelo:

```bash
./gerar_trafego_normal.sh 300
```

Ao terminar, pare a coleta com `Ctrl+C`.

**5.2 Classe `scan`** — no **Pi**:

```bash
sudo venv/bin/python collect.py scan --iface wlan1
```

No **Kali**, em paralelo:

```bash
./gerar_scans.sh
```

Pare a coleta com `Ctrl+C`. Repita os dois ciclos algumas vezes: quanto mais
amostras, melhor. Confira o resultado:

```bash
wc -l data.csv
```

Mire em pelo menos ~100 linhas, equilibradas entre as classes.

---

## Passo 6 — Treinar os modelos

```bash
cd ~/ids-ife
source venv/bin/activate
python train.py
```

A saída mostra precisão, matriz de confusão e a **importância das features** —
é a explicação do modelo, ótima para apresentar (costuma destacar
`n_dst_ports`, `synack_per_syn` e `mean_pkt_size`). Gera o `ids_model.pkl`.

> Treinou no PC? Copie o `ids_model.pkl` para a pasta do projeto no Pi.

---

## Passo 7 — Subir o painel em tempo real

```bash
cd ~/ids-ife
sudo IDS_IFACE=wlan1 venv/bin/uvicorn dashboard:app --host 0.0.0.0 --port 8000
```

Abra no navegador: **http://10.10.0.1:8000**

Variáveis opcionais: `IDS_WINDOW` (segundos por janela, padrão 10),
`IDS_SELF_IP`, `IDS_MODEL`, `IDS_DB`.

---

## Passo 8 — Demonstração

Com o painel aberto, no **Kali**:

```bash
# 1) tráfego legítimo — NÃO deve gerar alerta
curl http://10.10.0.1:8080/

# 2) scan rápido — alerta imediato, probabilidade alta
sudo nmap -sS -p 1-1000 10.10.0.1

# 3) scan lento — o diferencial da IA
sudo nmap -sS -T2 -p 1-500 10.10.0.1

# 4) scan furtivo
sudo nmap -sX -p 1-500 10.10.0.1
```

**O argumento central da apresentação:** uma regra fixa ("X portas por segundo")
erra o scan lento. O modelo, olhando a *combinação* de features — muitas portas
distintas + SYN sem SYN-ACK + pacotes minúsculos —, continua acertando.

---

## Solução de problemas

| Sintoma | Causa provável / solução |
|---|---|
| `Modo AP nao encontrado` | Antena não suporta AP. Use `wlan0` ou teste por cabo. |
| `sniff` não captura nada | Interface errada em `--iface`, ou faltou `sudo`. |
| Kali não recebe IP | Confirme `ipv4.method shared`; reconecte o Kali. |
| `externally-managed-environment` no pip | Use sempre o `venv/` (o setup já cria). |
| Painel abre mas fica vazio | Normal até haver tráfego. Rode um `nmap` no Kali. |
| Scan `-T0`/`-T1` não detectado | Aumente a janela: `IDS_WINDOW=30` ou `--window 30`. |
| Poucas amostras no treino | Repita o Passo 5 mais vezes. |

---

## Evoluções possíveis

- Adicionar mais hosts na rede para treinar **scan horizontal**.
- Incorporar o dataset público **CICIDS2017** (tem captura de PortScan rotulada).
- Comparar o Random Forest com **XGBoost/LightGBM**.
- Gráficos históricos no painel a partir do `alerts.db`.
- Serviço `systemd` para o IDS subir sozinho no boot.
